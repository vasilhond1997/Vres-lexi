//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import javax.swing.*;
import java.awt.*;


//Κλάση για τη δημιουργία γράμματος
public abstract class Letter extends JPanel {
    protected Color color;//Τρέχον χρώμα του γράμματος
    protected Color originalColor;//Βασικό χρώμα του γράμματος
    protected String letter;//Γράμμα
    protected int grade;//Βαθμός γράμματος

    protected int posx;//Θέση Χ του γράμματος
    protected int posy;//Θέση Υ του γράμματος

    
    Letter(String letter, int grade,int posx,int posy){
        this.letter=letter;
        this.grade=grade;
        this.posx=posx;
        this.posy=posy;
        setPreferredSize(new Dimension(70, 70));
        JLabel label1=new JLabel(letter);
        label1.setFont(new Font("Arial", Font.PLAIN, 40));
        String strGrade= Integer.toString(grade);
        JLabel label2=new JLabel(strGrade);
        label2.setFont(new Font("Arial", Font.PLAIN, 20));
        add(label1);
        add(label2);

    }
    Letter(int posx,int posy){
        this.posx=posx;
        this.posy=posy;
    }

    public void setColor(Color color) {
        this.color = color;
        setBackground(this.color);
    }

    public int getPosx() {
        return posx;
    }

    public int getPosy() {
        return posy;
    }

    public Color getColor() {
        return color;
    }

    public String getLetter() {
        return letter;
    }

    public int getGrade() {
        return grade;
    }



    public void undo(){
        color=originalColor;
        setBackground(color);
    }

    @Override
    public String toString() {
        return "Letter{" +
                "color=" + color +
                ", letter='" + letter + '\'' +
                ", grade=" + grade +
                ", posx=" + posx +
                ", posy=" + posy +
                '}';
    }

}
