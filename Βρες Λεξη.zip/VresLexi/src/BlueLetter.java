//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import java.awt.*;

public class BlueLetter extends Letter{

    BlueLetter(String letter, int grade,int posx,int posy) {
        super(letter, grade,posx,posy);
        originalColor=Color.BLUE;
        color= originalColor;
        setBackground(color);
    }
}
