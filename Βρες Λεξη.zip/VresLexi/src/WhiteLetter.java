//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import java.awt.*;

public class WhiteLetter extends Letter{

    WhiteLetter(String letter, int grade,int posx,int posy) {
        super(letter, grade,posx,posy);
        originalColor=Color.WHITE;
        color= originalColor;
        setBackground(color);
    }
}
