//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

//Κλάση που αφορά το βασικό πανελ του παιχνιδιού
public class Game extends JPanel {

    private String userName;//Μεταβλητή για την αποθήκευση του ονόματος του χρήστη

    private String userSurname;//Μεταβλητή για την αποθήκευση του επώνυμου του χρήστη
    private int tableuSize;
    private ArrayList<String> words;//Λίστα για την αποθήκευση των λέξεων του αρχείου
    private String filePath;//Μεταβλητή για την αποθήκευση του ονόματος του αρχείου
    private Tableu tableu;
    private JPanel helpPanel;
    private JPanel statistics;

    private JButton checkword;

    private JTextField rowIdDel;
    private JTextField rowIdShuffle;
    private JTextField columnIdShuffle;
    private JLabel deleteRowLabel;
    private JLabel allShuffleLabel;
    private JLabel rowShuffleLabel;
    private JLabel columnShuffleLabel;
    private int totalScore;//Μεταβλητή για την αποθήκευση του συνολικού score του παίκτη
    private int numOfWords;//Μεταβλητή για την αποθήκευση του πλήθους των λέξεων που βρέθηκαν
    private int latestWordScore;//Μεταβλητή για την αποθήκευση του score της τελευταίας λέξης που βρέθηκε
    private String latestWord;//Μεταβλητή για την αποθήκευση της τελευταίας λέξης που βρέθηκε

    private int countShuffleRow; //Μετρητής για τη βοήθεια "Αναδιάταξη γραμμής"
    private int countShuffleCol;//Μετρητής για τη βοήθεια "Αναδιάταξη στήλης"
    private int countShuffleTotal;//Μετρητής για τη βοήθεια "Αναδιάταξη ταμπλό"
    private int countDelRow;//Μετρητής για τη βοήθεια "Διαγραφή γραμμής"




    //Αρχικοποίηση παιχνιδιού
    Game(int tableuSize, String filePath) {
        this.tableuSize = tableuSize;
        this.filePath = filePath;
        newGame();
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserSurname(String userSurname) {
        this.userSurname = userSurname;
    }

    //Μέθοδος για τη δημιουργία του πάνελ στατιστικών
    public void setStats() {
        statistics.add(new JLabel("Στόχος:"));
        statistics.add(new JLabel("200"));
        statistics.add(new JLabel("Συνολική Βαθμολογία:"));
        statistics.add(new JLabel(Integer.toString(totalScore)));
        statistics.add(new JLabel("Βαθμολογία λέξης"));
        statistics.add(new JLabel(Integer.toString(latestWordScore)));
        statistics.add(new JLabel("Λέξεις που βρέθηκαν:"));
        statistics.add(new JLabel(Integer.toString(numOfWords)));
        statistics.add(new JLabel("Συγχαρητήρια βρήκες την λέξη:"));
        statistics.add(new JLabel(latestWord));
    }

    //Μέθοδος για τη δημιουργία του πάνελ των βοηθειών
    public void setHelps() {

        helpPanel.setLayout(new GridBagLayout());

        GridBagConstraints constraints = new GridBagConstraints();
        /////////////////////////////////////////////////////////
        //Λειτουργίες της βοήθειας "Διαγραφή γραμμής"
        /////////////////////////////////////////////////////////
        JButton deleteRow = new JButton("Διαγραφή γραμμής");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(deleteRow, constraints);

        rowIdDel = new JTextField("", 5);
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(rowIdDel, constraints);

        deleteRowLabel = new JLabel(countDelRow + "/3");
        constraints.gridx = 2;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(deleteRowLabel, constraints);
        deleteRow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String s;
                int num = 0;
                boolean wrongFormat = false;
                try {
                    s = rowIdDel.getText();
                    num = Integer.parseInt(s);
                    if (num < 1 || num > tableu.getTableuSize())
                        wrongFormat = true;
                } catch (NumberFormatException e) {
                    wrongFormat = true;
                }
                if (wrongFormat)
                    JOptionPane.showMessageDialog(null, "Το πεδίο θα πρέπει να περιέχει αριθμό από 1 - " + tableu.getTableuSize());
                else if (countDelRow >= 3) {
                    deleteRow.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Η βοήθεια \"Διαγραφή γραμμής\" μπορεί να χρησιμοποιηθεί μέχρι 3 φορές");
                } else {
                    tableu.deleteRow(num - 1);
                    countDelRow++;
                    deleteRowLabel.setText(countDelRow + "/3");

                    validate();
                    repaint();
                }
            }
        });

        /////////////////////////////////////////////////////////
        //Λειτουργίες της βοήθειας "Αναδιάταξη γραμμής"
        /////////////////////////////////////////////////////////
        JButton shuffleRow = new JButton("Αναδιάταξη γραμμής");
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(shuffleRow, constraints);
        shuffleRow.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String s;
                int num = 0;
                boolean wrongFormat = false;
                try {
                    s = rowIdShuffle.getText();
                    num = Integer.parseInt(s);
                    if (num < 1 || num > tableu.getTableuSize())
                        wrongFormat = true;
                } catch (NumberFormatException e) {
                    wrongFormat = true;
                }
                if (wrongFormat)
                    JOptionPane.showMessageDialog(null, "Το πεδίο θα πρέπει να περιέχει αριθμό από 1 - " + tableu.getTableuSize());
                else if (countShuffleRow >= 3) {
                    shuffleRow.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Η βοήθεια \"Αναδιάταξη γραμμής\" μπορεί να χρησιμοποιηθεί μέχρι 3 φορές");
                } else {
                    tableu.shuffleRow(num - 1);
                    countShuffleRow++;
                    rowShuffleLabel.setText(countShuffleRow + "/3");

                    validate();
                    repaint();
                }
            }
        });

        rowIdShuffle = new JTextField("", 5);

        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(rowIdShuffle, constraints);

        rowShuffleLabel = new JLabel(countShuffleRow + "/3");
        constraints.gridx = 2;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(rowShuffleLabel, constraints);

        /////////////////////////////////////////////////////////
        //Λειτουργίες της βοήθειας "Αναδιάταξη στήλης"
        /////////////////////////////////////////////////////////
        JButton shuffleColumn = new JButton("Αναδιάταξη στήλης");
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(shuffleColumn, constraints);
        shuffleColumn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                int num = 0;
                boolean wrongFormat = false;
                try {
                    String s = columnIdShuffle.getText();
                    num = Integer.parseInt(s);
                    if (num < 1 || num > tableu.getTableuSize())
                        wrongFormat = true;
                } catch (NumberFormatException e) {
                    wrongFormat = true;
                }
                if (wrongFormat)
                    JOptionPane.showMessageDialog(null, "Το πεδίο θα πρέπει να περιέχει αριθμό από 1 - " + tableu.getTableuSize());
                else if (countShuffleCol >= 3) {
                    shuffleColumn.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Η βοήθεια \"Αναδιάταξη στήλης\" μπορεί να χρησιμοποιηθεί μέχρι 3 φορές");
                } else {
                    tableu.shuffleColumn(num - 1);
                    countShuffleCol++;
                    columnShuffleLabel.setText(countShuffleCol + "/3");

                    validate();
                    repaint();
                }
            }
        });


        columnIdShuffle = new JTextField("", 5);

        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(columnIdShuffle, constraints);

        columnShuffleLabel = new JLabel(countShuffleCol + "/3");
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(columnShuffleLabel, constraints);

        /////////////////////////////////////////////////////////
        //Λειτουργίες της βοήθειας "Αναδιάταξη ταμπλό"
        /////////////////////////////////////////////////////////
        JButton shuffleAll = new JButton("Αναδιάταξη ταμπλό");
        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(shuffleAll, constraints);

        allShuffleLabel = new JLabel(countShuffleTotal + "/5");
        constraints.gridx = 2;
        constraints.gridy = 3;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        helpPanel.add(allShuffleLabel, constraints);

        shuffleAll.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                if (countShuffleTotal >= 5) {
                    shuffleAll.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Η βοήθεια \"Αναδιάταξη Ταμπλό\" μπορεί να χρησιμοποιηθεί μέχρι 3 φορές");
                }
                else {

                    tableu.shuffleTableu();
                    countShuffleTotal++;
                    allShuffleLabel.setText(countShuffleTotal + "/5");

                    validate();
                    repaint();
                }
            }
        });


    }

    //Μέθοδος για την αρχικοποίηση του ταμπλό
    public void newGame() {
        removeAll();

        numOfWords = 0;
        totalScore = 0;
        latestWordScore = 0;
        latestWord = "";
        countShuffleCol = 0;
        countShuffleRow = 0;
        countDelRow = 0;
        countShuffleTotal = 0;
        importFile(filePath);

        tableu = new Tableu(8);

        tableu.chooseWords(words);
        tableu.initialize();
        checkword = new JButton("Έλεγχος λέξης");
        helpPanel = new JPanel();
        statistics = new JPanel();
        statistics.setLayout(new GridLayout(5, 2));
        setStats();
        setHelps();

        add(tableu);
        add(checkword);
        add(statistics);
        add(helpPanel);


        checkword.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                String foundWord = tableu.checkWord();
                if (foundWord != null) {
                    latestWordScore = tableu.calculateGrade();
                    JOptionPane.showMessageDialog(null, "Συγχαρητήρια βρέθηκε η λέξη: " + foundWord);

                    tableu.replaceWord();
                    totalScore += latestWordScore;
                    numOfWords++;
                    latestWord = foundWord;
                    statistics.removeAll();
                    setStats();
                    validate();
                    repaint();
                    if (totalScore >= 200)
                        JOptionPane.showMessageDialog(null, statistics, "Τερματισμός παιχνιδιού", JOptionPane.INFORMATION_MESSAGE);


                } else {
                    JOptionPane.showMessageDialog(null, "Η λέξη δεν βρέθηκε!");

                    tableu.restoreWord();
                    validate();
                    repaint();

                }
            }
        });

    }

    //Μέθοδος για την εισαγωγή του αρχείου
    public void importFile(File file) {
        words = new ArrayList<>();

        Scanner scanner;
        try {
            scanner = new Scanner(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        while (scanner.hasNext()) {
            words.add(scanner.next());
        }
    }

    //Μέθοδος για την εισαγωγή του αρχείου
    public void importFile(String filePath) {
        words = new ArrayList<>();

        this.filePath = filePath;
        File file = new File(filePath);
        Scanner scanner;
        try {
            scanner = new Scanner(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        while (scanner.hasNext()) {
            words.add(scanner.next());
        }
    }


    public JPanel getStatistics() {
        return statistics;
    }
}
