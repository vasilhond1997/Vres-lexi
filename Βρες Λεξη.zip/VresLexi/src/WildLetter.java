//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import javax.swing.*;
import java.awt.*;
import java.util.Set;

public class WildLetter extends Letter{

    WildLetter(int posx,int posy) {
        super(posx,posy);
        originalColor=Color.WHITE;
        color= originalColor;
        setPreferredSize(new Dimension(50, 30));
        JLabel label1=new JLabel("?");
        label1.setFont(new Font("Arial", Font.PLAIN, 40));
        add(label1);
        setBackground(color);
    }

    public String  chooseLetter(Set<String > keySet){
        Object[] possibilities = keySet.toArray();
        String s = (String)JOptionPane.showInputDialog(
                this,
                "Επιλέξτε ένα γράμμα από την παρακάτω λίστα:\n",
                "Επιλογή γράμματος",
                JOptionPane.PLAIN_MESSAGE,null,
                possibilities,
                "Α");

        return s;
    }

    public void addLetterAndScore(String letter,int score){
        removeAll();
        this.letter=letter;
        this.grade=score;
        this.color=Color.YELLOW;
        JLabel label1=new JLabel(letter);
        label1.setFont(new Font("Arial", Font.PLAIN, 40));

        String strGrade= Integer.toString(score);
        JLabel label2=new JLabel(strGrade);
        label2.setFont(new Font("Arial", Font.PLAIN, 20));
        add(label1);
        add(label2);
        setBackground(color);
    }

    public void restoreState(){
        removeAll();
        JLabel label1=new JLabel("?");
        label1.setFont(new Font("Arial", Font.PLAIN, 40));
        add(label1);
        color=Color.WHITE;
        setBackground(color);


    }
}
