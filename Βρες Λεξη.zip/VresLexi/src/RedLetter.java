//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import java.awt.*;

public class RedLetter extends Letter {
    RedLetter(String letter, int grade,int posx,int posy) {
        super(letter, grade,posx,posy);
        this.grade=2*grade;
        originalColor=Color.RED;
        color= originalColor;
        setBackground(color);
    }
}
