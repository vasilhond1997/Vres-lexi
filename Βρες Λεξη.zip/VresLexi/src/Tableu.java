//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;

public class Tableu extends JPanel {


    private int countRed;//Πλήθος των κόκκινων γραμμάτων στο ταμπλό
    private int countBlue;//Πλήθος των μπλε γραμμάτων στο ταμπλό
    private int countWild;//Πλήθος των μπαλαντερ στο ταμπλό

    private final int size; //Μέγεθος μίας πλευράς του ταμπλό

    //Λίστα που αποθηκεύει όλές τις λέξεις που θα περιέχει το ταμπλό
    private final ArrayList<String> chosenwords;

    //Λίστα που θα περιέχει όλους τους χαρακτήρες που θα υπάρχουν στο ταμπλό
    private final ArrayList<Character> letters;

    //Λίστα για την αποθήκευση των επιλεγμένων γραμματών από τον χρήστη
    private ArrayList<Letter> choosenLetters;

    //Λίστα για την αποθήκευση όλων των λέξεων του αρχείου
    private ArrayList<String> allWords;

    //HashMap για την αντιστοίχηση των χαρακτήρων με τις κατάλληλες βαθμολογίες τους
    private final HashMap<String, Integer> letterScores;

    //Δισδιάστατος πίνακας για την αποθήκευση των γραμμάτων που χρησιμοποιούνται για την δημιουργία του ταμπλό
    private Letter[][] panels;

    private boolean statusStart;//Μεταβλητή για το αν είναι αρχή του παιχνιδιού ή όχι

    private boolean useBlue;//Μεταβλητή για την αποθήκευση, αν υπάρχει μπλε γράμμα στην δημιουργημένη λέξη

    private int latestX;//Μεταβλητή για την αποθήκευση της θέσης Χ του τελευταίου γράμματος που επιλέχθηκε
    private int latestY;//Μεταβλητή για την αποθήκευση της θέσης Υ του τελευταίου γράμματος που επιλέχθηκε

    //Αρχικοποίηση των χαρακτηριστικών της κλάσης
    Tableu(int size) {
        this.size = size;
        GridLayout gridLayout = new GridLayout(size, size, 20, 20);
        setLayout(gridLayout);
        chosenwords = new ArrayList<>();
        letters = new ArrayList<>();
        choosenLetters = new ArrayList<>();
        allWords = new ArrayList<>();
        panels = new Letter[size][size];
        statusStart = true;
        useBlue = false;
        letterScores = new HashMap<String, Integer>() {{
            put("Α", 1);
            put("Β", 8);
            put("Γ", 4);
            put("Δ", 4);
            put("Ε", 1);
            put("Ζ", 8);
            put("Η", 1);
            put("Θ", 8);
            put("Ι", 1);
            put("Κ", 2);
            put("Λ", 3);
            put("Μ", 3);
            put("Ν", 1);
            put("Ξ", 10);
            put("Ο", 1);
            put("Π", 2);
            put("Ρ", 2);
            put("Σ", 1);
            put("Τ", 1);
            put("Υ", 2);
            put("Φ", 8);
            put("Χ", 10);
            put("Ψ", 10);
            put("Ω", 3);
        }};
    }

    //Μέθοδος για την επιλογής των λέξεων από τη λίστα των λέξεων που δημιουργήθηκε από το αρχείο
    public void chooseWords(ArrayList<String> words) {
        allWords = words;
        int numberOfLetters = 0;
        int trueNumOfLetters = 0;
        Random rand = new Random();
        int index;
        while (true) {
            //Τυχαία επιλογή λέξης
            index = rand.nextInt(words.size());
            String randomString = words.get(index);
            if (!chosenwords.contains(randomString)) {
                numberOfLetters += randomString.length();

                //Έλεγχος αν δεν ξεπερνάτε το σύνολο των γραμμάτων που επιτρέπεται να υπάρχουν στο ταμπλό
                if (numberOfLetters > size * size) break;
                trueNumOfLetters += randomString.length();

                //Προσθήκη των γραμμάτων των επιλεγμένων λέξεων στη λίστα των λέξεων
                for (int i = 0; i < randomString.length(); i++)
                    letters.add(randomString.charAt(i));

                //Προσθήκη της επιλεγμένης λέξης στην κατάλληλη λίστα
                chosenwords.add(randomString);
            }
        }
        //Συμπλήρωση της λίστας των γραμμάτων με επιπλέον γράμματα σε
        //περίπτωση που δεν έχει συμπληρωθεί ο αριθμός των γραμμάτων του ταμπλό
        while (trueNumOfLetters < size * size) {
            Random r = new Random();
            char c = (char) (r.nextInt(24) + 'Α');
            if (letterScores.get(Character.toString(c)) != null) {
                letters.add(c);
                trueNumOfLetters++;
            }
        }
        //Τυχαίο ανακάτεμα της λίστας των γραμμάτων
        Collections.shuffle(letters);

    }


    //Μέθοδος για την αρχικοποίηση του ταμπλό(χρήση γραφικών)
    public void initialize() {
        int charIdx = 0;// Μετρητής για το πλήθος των χαρακτήρων που υπάρχουν στην λίστα letters
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Character c = letters.get(charIdx);

                String character = Character.toString(c);
                Random random = new Random();
                int choice;
                //Τυχαία επιλογή του τύπου γράμματος που θα προστεθεί στο ταμπλό
                while (true) {
                    choice = random.nextInt(4);
                    if (choice == 0) break;
                    else if (choice == 1 && countRed < 2) break;
                    else if (choice == 2 && countBlue < 3) break;
                    else if (choice == 3 && countWild < 4) break;
                }

                //Δημιουργία ενός αντικειμένου τύπου Letter
                Letter letterObj = createLetter(choice, character, letterScores.get(character), i, j);
                letterObj.addMouseListener(mouseListener);//Προσθήκη listener στο αντικείμενο που δημιουργήθηκε
                panels[i][j] = letterObj;//Προσθήκη του αντικειμένου Letter στον διστιάστατο πίνακα
                add(letterObj); //Προσθήκη του αντικειμένου Letter στο JPanel που αφορά το ταμπλό
                charIdx++;
            }
        }
    }

    //Βοηθητική συνάρτηση για τη δημιουργία ενός αντικειμένου τύπου Letter
    private Letter createLetter(int choice, String letter, int grade, int posx, int posy) {
        switch (choice) {
            case 1: {
                countRed++;
                return new RedLetter(letter, grade, posx, posy);
            }
            case 2: {
                countBlue++;
                return new BlueLetter(letter, grade, posx, posy);
            }
            case 3: {
                countWild++;
                return new WildLetter(posx, posy);
            }
            default:
                return new WhiteLetter(letter, grade, posx, posy);
        }

    }


    //Βοηθητική μέθοδος για τη δημιουργία τυχαίου γράμματος
    private Letter createRandomLetter(int posx, int posy) {
        Random random = new Random();
        int choice;
        while (true) {
            choice = random.nextInt(4);
            if (choice == 0) break;
            else if (choice == 1 && countRed < 2) break;
            else if (choice == 2 && countBlue < 3) break;
            else if (choice == 3 && countWild < 4) break;
        }
        Random r = new Random();
        char c;
        do {
            c = (char) (r.nextInt(24) + 'Α');
        } while (letterScores.get(Character.toString(c)) == null);
        return createLetter(choice, Character.toString(c), letterScores.get(Character.toString(c)), posx, posy);
    }

    //Μέθοδος για την αντικατάσταση των γραμμάτων της λέξης που βρέθηκε (καλείται μόνο αν υπάρχει η λέξη)
    public void replaceWord() {
        //Επανάλληψη για την ανανέωση των γραμμάτων που αποθηκεύτηκαν στην λίστα επιλεγμένων γραμμάτων
        for (Letter l : choosenLetters) {
            int posx = l.getPosx();
            int posy = l.getPosy();
            remove(l);
            //Δημιουργία νέου τυχαίου γράμματος και προσθήκη στο ταμπλό
            Letter letterObj = createRandomLetter(posx, posy);
            letterObj.addMouseListener(mouseListener);
            panels[posx][posy] = letterObj;
        }
        statusStart = true;
        replaceTableu();

        choosenLetters = new ArrayList<>();
    }

    //Επαναφορά του ταμπλό στην αρχική του κατάσταση
    public void restoreWord() {
        for (Letter l : choosenLetters) {
            int posx = l.getPosx();
            int posy = l.getPosy();
            Letter letterObj = panels[posx][posy];
            letterObj.undo();
        }
        statusStart = true;
        replaceTableu();

        //Αρχικοποίηση της λίστας των επιλεγμένων γραμμάτων
        choosenLetters = new ArrayList<>();
    }

    //Βοηθητική μέθοδος για την ανανέωση των γραφικών στην τελική τους κατάσταση
    private void replaceTableu() {
        removeAll();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                add(panels[i][j]);
            }

        }
    }


    //Μέθοδος για τον έλεγχο των κανόνων γειτνίασης
    private boolean checkNeighbors(int posx, int posy) {
        for (int i = posx - 1; i <= posx + 1; i++)
            for (int j = posy - 1; j <= posy + 1; j++) {
                if (inBorders(i, j)) {
                    if (panels[i][j].getColor() == Color.YELLOW)
                        return true;

                }
            }
        return false;
    }

    //Υπολογισμός του βαθμού της λέξης
    public int calculateGrade() {
        int totalGrade = 0;
        for (Letter l : choosenLetters) {
            totalGrade += l.getGrade();
        }
        if (useBlue) totalGrade *= 2;

        return totalGrade;
    }

    //Μέθοδος για έλεγχο αν η επιλεγμένη λέξη ανήκει στη λίστα των λέξεων
    public String checkWord() {
        boolean wordFound = false;
        String retWord = null;

        for (String word : allWords) {

            if (word.length() == choosenLetters.size()) {
                wordFound = true;
                for (Letter l : choosenLetters) {
                    if (!word.contains(l.getLetter())) {
                        wordFound = false;
                        break;
                    }
                }
            }
            if (wordFound) {
                retWord = word;
                break;
            }
        }
        return retWord;
    }

    public int getTableuSize() {
        return size;
    }


    //Μέθοδοι που χρησιμοποιούνται για την υλοποίηση των βοηθειών

    //Μέθοδος για την αντικατάσταση των γραμμάτων μίας επιλεγμένης γραμμής του ταμπλό
    public void deleteRow(int rowIdx) {
        for (int j = 0; j < size; j++) {
            remove(panels[rowIdx][j]);
            Letter letterObj = createRandomLetter(rowIdx, j);
            letterObj.addMouseListener(mouseListener);
            panels[rowIdx][j] = letterObj;
        }
        replaceTableu();
    }

    //Μέθοδος για την αναδιάταξη των γραμμάτων μίας επιλεγμένης γραμμής του ταμπλό
    public void shuffleRow(int rowIdx) {
        Random rand = new Random();
        for (int j = 0; j < size; j++) {
            int randomIndexToSwap = rand.nextInt(size);
            Letter temp = panels[rowIdx][randomIndexToSwap];
            panels[rowIdx][randomIndexToSwap] = panels[rowIdx][j];
            panels[rowIdx][j] = temp;
        }
        replaceTableu();
    }

    //Μέθοδος για την αναδιάταξη των γραμμάτων μίας επιλεγμένης στήλης του ταμπλό
    public void shuffleColumn(int columnIdx) {
        Random rand = new Random();
        for (int j = 0; j < size; j++) {
            int randomIndexToSwap = rand.nextInt(size);
            Letter temp = panels[randomIndexToSwap][columnIdx];
            panels[randomIndexToSwap][columnIdx] = panels[j][columnIdx];
            panels[j][columnIdx] = temp;
        }
        replaceTableu();

    }

    //Μέθοδος για την αναδιάταξη όλων των γραμμάτων του ταμπλό
    public void shuffleTableu() {
        Random rand = new Random();
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++) {

                int randomX = rand.nextInt(size);
                int randomY = rand.nextInt(size);
                Letter temp = panels[randomX][randomY];
                panels[randomX][randomY] = panels[i][j];
                panels[i][j] = temp;
            }
        replaceTableu();
    }

    //Βοηθητική συνάρτηση που χρησιμεύει στον έλεγχο των κανόνων γειτνίασης
    private boolean inBorders(int x, int y) {
        return x >= 0 && x < size && y >= 0 && y < size;
    }

    //Listener για να πραγματοποιείται η λειτουργία αλλαγής χρώματος όταν ένα γράμμα επιλέγεται
    MouseAdapter mouseListener = new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            Letter letter = (Letter) e.getSource();

            int x = letter.getPosx();
            int y = letter.getPosy();
            Letter choosenLetter = panels[x][y];

            if (choosenLetter.getColor() == Color.YELLOW && x == latestX && y == latestY) {
                choosenLetter.undo();
                choosenLetters.remove(choosenLetter);

            } else if (statusStart) {

                if (choosenLetter.getColor() == Color.BLUE) {
                    useBlue = true;
                }
                if (choosenLetter.getClass().getName().equals("WildLetter")) {
                    String s = ((WildLetter) choosenLetter).chooseLetter(letterScores.keySet());
                    if (s != null) {
                        ((WildLetter) choosenLetter).addLetterAndScore(s, letterScores.get(s));
                        choosenLetters.add(choosenLetter);

                        validate();
                        repaint();

                    }
                } else {
                    choosenLetter.setColor(Color.YELLOW);
                    choosenLetter.setBackground(Color.YELLOW);
                    choosenLetters.add(choosenLetter);
                }
                statusStart = false;


                latestX = choosenLetter.getPosx();
                latestY = choosenLetter.getPosy();

            } else if (checkNeighbors(x, y)) {

                if (choosenLetter.getColor() == Color.BLUE) {
                    useBlue = true;
                }


                if (choosenLetter.getClass().getName().equals("WildLetter")) {
                    String s = ((WildLetter) choosenLetter).chooseLetter(letterScores.keySet());
                    if (s != null) {
                        ((WildLetter) choosenLetter).addLetterAndScore(s, letterScores.get(s));
                        choosenLetters.add(choosenLetter);

                        validate();
                        repaint();

                    }
                } else {
                    choosenLetter.setColor(Color.YELLOW);
                    choosenLetter.setBackground(Color.YELLOW);
                    choosenLetters.add(choosenLetter);
                }

                latestX = choosenLetter.getPosx();
                latestY = choosenLetter.getPosy();

            }

        }
    };

}
