//ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219
//ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
public class Main {

    public static void main(String[] args) {
        // Δημιουργία του Frame
        JFrame frame = new JFrame("Βρες την λέξη");

        //Δημιουργία των ΜΕΝΟΥ
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("Menu");
        menuBar.add(fileMenu);
        JMenu HelpMenu = new JMenu("Βοήθεια");
        menuBar.add(HelpMenu);

        JMenuItem newGameItem = new JMenuItem("Νέο παιχνίδι");
        JMenuItem userDetailsItem= new JMenuItem("Εισαγωγή στοιχείων χρήστη");
        JMenuItem gameInstructionsItem = new JMenuItem("Οδηγίες παιχνιδιού");
        JMenuItem aboutItem = new JMenuItem("About");
        JMenuItem exitItem=new JMenuItem("Έξοδος παιχνιδιού");
        JMenuItem importFileItem=new JMenuItem("Επιλογή αρχείου λέξεων");
        JMenuItem endGame=new JMenuItem("Ακύρωση-Τερματισμός παιχνιδιού");

        fileMenu.add(newGameItem);
        fileMenu.add(userDetailsItem);
        fileMenu.add(exitItem);
        fileMenu.add(importFileItem);
        fileMenu.add(endGame);

        HelpMenu.add(gameInstructionsItem);
        HelpMenu.add(aboutItem);

        //Δημιουργία αντικειμένου game
        Game game=new Game(8,"Words");

        frame.setJMenuBar(menuBar);
        frame.add(game);

        //Λειτουργίες των ΜΕΝΟΥ
        newGameItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                game.newGame();

                frame.validate();
                frame.repaint();
            }

        });

        userDetailsItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JPanel panel = new JPanel(new GridLayout(2,2));
                JLabel nameLabel=new JLabel("Όνομα");
                JTextField nameInput = new JTextField(50);
                JLabel surnameLabel=new JLabel("Επίθετο");
                JTextField surnameInput = new JTextField(50);
                panel.add(nameLabel);
                panel.add(nameInput);
                panel.add(surnameLabel);
                panel.add(surnameInput);
                JOptionPane.showMessageDialog(null,panel);
                game.setUserName(nameInput.getText());
                game.setUserSurname(surnameInput.getText());
            }
        });

        importFileItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                int result = fileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    game.importFile(selectedFile);
                }

            }
        });

        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a=JOptionPane.showConfirmDialog(null,"Θέλετε σίγουρα να κλείσετε το παιχνίδι?");
                if(a==JOptionPane.YES_OPTION){
                    frame.dispose();
                }
            }
        });

        endGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JOptionPane.showMessageDialog(null,game.getStatistics(),"Τερματισμός παιχνιδιού",JOptionPane.INFORMATION_MESSAGE);
            }
        });

        gameInstructionsItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String instructions="Δημιουργία λέξης:\n" +
                        "Για την δημιουργία λέξεις θα πρέπει να επιλεγεί το πρώτο γράμμα" +
                        "και στην συνέχεια όλα τα υπόλοιπα θα πρέπει να είναι γειτονικά.\n" +
                        "Βαθμολογίες γραμμάτων: \n" +
                        "Γράμματα με άσπρο φόντο -> Ισχύει η βαθμολογιά που αναγράφεται δίπλα στο γράμμα\n" +
                        "Γράμματα με κόκκινο φόντο -> Διπλάσια βαθμολογία από αυτή που αναγράφεται δίπλα στο γράμμα\n" +
                        "Γράμματα με μπλε φόντο -> Διπλασιάζουν την συνολική βαθμολογία της λέξης όταν επιλέγονται";
                JOptionPane.showMessageDialog(null,instructions,"Οδηγίες",JOptionPane.INFORMATION_MESSAGE);

            }
        });

        aboutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JOptionPane.showMessageDialog(null,"Δημιουργός 1: ΧΟΝΔΡΟΓΙΑΝΝΗΣ ΒΑΣΙΛΗΣ icsd15219\n" +
                        "Δημιουργός 2: ΣΚΑΜΑΤΖΟΥΡΑ ΑΘΗΝΑ icsd16181");

            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1080, 1080);
        frame.setVisible(true);

    }

}